import { createServer } from 'node:http';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PROJECT_ROOT = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_PUBLIC_DIR = path.join(PROJECT_ROOT, 'public');
const MAX_BODY_BYTES = 12 * 1024;
const NOTIFICATION_TIMEOUT_MS = 15_000;
const RATE_LIMIT_MAX = 5;
const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;
const GLOBAL_RATE_LIMIT_MAX = 100;
const TOPICS = Object.freeze([
  'Partnership',
  'Mission services',
  'Careers',
  'Press',
  'Other',
]);

const MIME_TYPES = Object.freeze({
  '.avif': 'image/avif',
  '.css': 'text/css; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8',
  '.gif': 'image/gif',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.mp3': 'audio/mpeg',
  '.mp4': 'video/mp4',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.txt': 'text/plain; charset=utf-8',
  '.webm': 'video/webm',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.xml': 'application/xml; charset=utf-8',
});

class BodyTooLargeError extends Error {
  constructor() {
    super('Request body is too large.');
    this.code = 'BODY_TOO_LARGE';
  }
}

class InvalidRequestBodyError extends Error {
  constructor() {
    super('Invalid request body.');
    this.code = 'INVALID_REQUEST_BODY';
  }
}

function jsonByteLength(value) {
  return Buffer.byteLength(JSON.stringify(value), 'utf8');
}

function hasControlCharacters(value, { allowLineBreaks = false } = {}) {
  for (const character of value) {
    const code = character.codePointAt(0);
    if (code === 0 || code === 0x7f) return true;
    if (code < 0x20 && !(allowLineBreaks && (code === 0x09 || code === 0x0a || code === 0x0d))) {
      return true;
    }
  }
  return false;
}

function characterLength(value) {
  return Array.from(value).length;
}

function validEmail(value) {
  if (value.length > 254 || Buffer.byteLength(value, 'utf8') > 254) return false;
  if (hasControlCharacters(value) || /\s/.test(value)) return false;

  const atIndex = value.indexOf('@');
  if (atIndex <= 0 || atIndex !== value.lastIndexOf('@')) return false;

  const localPart = value.slice(0, atIndex);
  const domain = value.slice(atIndex + 1);
  if (!localPart || !domain || Buffer.byteLength(localPart, 'utf8') > 64) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) return false;
  if (domain.startsWith('.') || domain.endsWith('.') || domain.includes('..')) return false;

  const labels = domain.split('.');
  if (labels.some((label) => {
    if (!label || label.startsWith('-') || label.endsWith('-')) return true;
    return !/^[\p{L}\p{N}-]+$/u.test(label);
  })) return false;

  return true;
}

function validateTextField(payload, field, { min, max, allowLineBreaks = false, required = true } = {}, errors, output) {
  const raw = payload[field];
  if (raw === undefined && !required) {
    output[field] = '';
    return;
  }
  if (typeof raw !== 'string') {
    errors[field] = 'must be text';
    return;
  }

  const value = raw.trim();
  const length = characterLength(value);
  if (length < min || length > max) {
    errors[field] = `must be ${min}–${max} characters`;
    return;
  }
  if (hasControlCharacters(value, { allowLineBreaks })) {
    errors[field] = 'contains unsupported control characters';
    return;
  }
  output[field] = value;
}

export function validateInquiry(payload) {
  const errors = {};
  const output = {};

  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return { ok: false, errors: { body: 'must be a JSON object' } };
  }

  validateTextField(payload, 'name', { min: 2, max: 100 }, errors, output);

  if (typeof payload.email !== 'string') {
    errors.email = 'must be text';
  } else {
    const email = payload.email.trim();
    if (!validEmail(email)) errors.email = 'must be a valid email address';
    else output.email = email;
  }

  if (payload.organization === undefined) {
    output.organization = '';
  } else if (typeof payload.organization !== 'string') {
    errors.organization = 'must be text';
  } else {
    const organization = payload.organization.trim();
    if (characterLength(organization) > 120) errors.organization = 'must be at most 120 characters';
    else if (hasControlCharacters(organization)) errors.organization = 'contains unsupported control characters';
    else output.organization = organization;
  }

  if (typeof payload.topic !== 'string' || !TOPICS.includes(payload.topic.trim())) {
    errors.topic = `must be one of: ${TOPICS.join(', ')}`;
  } else {
    output.topic = payload.topic.trim();
  }

  validateTextField(payload, 'message', { min: 20, max: 3000, allowLineBreaks: true }, errors, output);

  if (payload.consent !== true) errors.consent = 'must be true';

  if (payload.website !== undefined && payload.website !== '') {
    errors.website = 'must be empty';
  }

  if (Object.keys(errors).length > 0) return { ok: false, errors };
  return { ok: true, value: output };
}

export function buildNotification(payload) {
  const organization = payload.organization || '(not provided)';
  return {
    title: `Quasar Space · ${payload.topic} inquiry`,
    content: [
      `Name: ${payload.name}`,
      `Email: ${payload.email}`,
      `Organization: ${organization}`,
      `Topic: ${payload.topic}`,
      '',
      'Message:',
      payload.message,
    ].join('\n'),
  };
}

function parseRequestTarget(target) {
  const requestTarget = typeof target === 'string' && target.length > 0 ? target : '/';
  const queryStart = requestTarget.indexOf('?');
  const rawPath = queryStart === -1 ? requestTarget : requestTarget.slice(0, queryStart);
  if (!rawPath.startsWith('/') || rawPath.length > 4096 || rawPath.includes('\u0000')) {
    throw new Error('Invalid request target.');
  }

  let decodedPath;
  try {
    decodedPath = decodeURIComponent(rawPath);
  } catch {
    throw new Error('Invalid request target.');
  }

  if (!decodedPath.startsWith('/') || decodedPath.includes('\u0000')) {
    throw new Error('Invalid request target.');
  }

  const pathSegments = decodedPath.split(/[\\/]+/u);
  if (pathSegments.some((segment) => segment === '..' || segment === '.')) {
    return { pathname: decodedPath, forbidden: true };
  }

  return { pathname: decodedPath, forbidden: false };
}

function isInside(root, candidate) {
  return candidate === root || candidate.startsWith(`${root}${path.sep}`);
}

async function resolvePublicFile(publicDir, pathname) {
  const root = path.resolve(publicDir);
  let rootRealPath;
  try {
    rootRealPath = await fs.realpath(root);
  } catch {
    return null;
  }

  const candidate = path.resolve(root, `.${pathname}`);
  if (!isInside(root, candidate)) return null;

  let stats;
  let fileCandidate = candidate;
  try {
    stats = await fs.stat(fileCandidate);
    if (stats.isDirectory()) {
      fileCandidate = path.join(fileCandidate, 'index.html');
      stats = await fs.stat(fileCandidate);
    }
  } catch {
    return null;
  }
  if (!stats.isFile()) return null;

  let realFilePath;
  try {
    realFilePath = await fs.realpath(fileCandidate);
  } catch {
    return null;
  }
  if (!isInside(rootRealPath, realFilePath)) return null;

  return { filePath: realFilePath, stats };
}

function mimeTypeFor(filePath) {
  return MIME_TYPES[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

function sendJson(response, statusCode, payload, { headOnly = false } = {}) {
  const body = JSON.stringify(payload);
  response.statusCode = statusCode;
  response.setHeader('Content-Type', 'application/json; charset=utf-8');
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('Content-Length', Buffer.byteLength(body, 'utf8'));
  response.end(headOnly ? undefined : body);
}

function sendText(response, statusCode, body, { headOnly = false } = {}) {
  response.statusCode = statusCode;
  response.setHeader('Content-Type', 'text/plain; charset=utf-8');
  response.setHeader('Content-Length', Buffer.byteLength(body, 'utf8'));
  response.end(headOnly ? undefined : body);
}

async function serveFile(response, file, { statusCode = 200, headOnly = false } = {}) {
  response.statusCode = statusCode;
  response.setHeader('Content-Type', mimeTypeFor(file.filePath));
  response.setHeader('Content-Length', file.stats.size);
  if (headOnly) {
    response.end();
    return;
  }
  const contents = await fs.readFile(file.filePath);
  response.end(contents);
}

async function serveNotFound(response, publicDir, { headOnly = false } = {}) {
  const notFoundFile = await resolvePublicFile(publicDir, '/404.html');
  if (notFoundFile) {
    await serveFile(response, notFoundFile, { statusCode: 404, headOnly });
  } else {
    sendText(response, 404, 'Not Found\n', { headOnly });
  }
}

function sendMethodNotAllowed(response, allow) {
  response.setHeader('Allow', allow);
  sendJson(response, 405, { success: false, error: 'Method not allowed.' });
}

function requestUsesCrossSiteFetch(request) {
  const fetchSite = request.headers['sec-fetch-site'];
  return typeof fetchSite === 'string' && fetchSite.trim().toLowerCase() === 'cross-site';
}

function requestUsesSameOriginFetch(request) {
  const fetchSite = request.headers['sec-fetch-site'];
  if (typeof fetchSite !== 'string') return false;
  const normalized = fetchSite.trim().toLowerCase();
  return normalized === 'same-origin' || normalized === 'same-site';
}

function readSocketAddress(request) {
  const address = request.socket?.remoteAddress || request.connection?.remoteAddress;
  return typeof address === 'string' ? address : '';
}

function isLikelySharedLocalProxy(address) {
  return address === '' || address === '::' || address === '0.0.0.0' || address === '::1'
    || address === '127.0.0.1' || address === '::ffff:127.0.0.1';
}

function firstForwardedAddress(value) {
  if (typeof value !== 'string') return '';
  const candidate = value.split(',')[0]?.trim() || '';
  if (!candidate || candidate.length > 200 || /[\u0000-\u001f\u007f]/u.test(candidate)) return '';
  return candidate;
}

function createRateLimiter({ maxAttempts = RATE_LIMIT_MAX, windowMs = RATE_LIMIT_WINDOW_MS, globalMaxAttempts = GLOBAL_RATE_LIMIT_MAX, trustProxy = false } = {}) {
  const buckets = new Map();
  const globalBucket = [];

  function prune(bucket, now) {
    while (bucket.length > 0 && bucket[0] <= now - windowMs) bucket.shift();
  }

  function check(request) {
    const now = Date.now();
    const socketAddress = readSocketAddress(request);
    let key = socketAddress;
    if (trustProxy) key = firstForwardedAddress(request.headers['x-forwarded-for']) || socketAddress;

    const bucketKey = key || '__unknown__';
    const bucket = buckets.get(bucketKey) || [];
    const sharedProxyFallback = isLikelySharedLocalProxy(socketAddress) && requestUsesSameOriginFetch(request);
    prune(bucket, now);

    if (sharedProxyFallback) {
      prune(globalBucket, now);
      if (globalBucket.length >= globalMaxAttempts) {
        const retryAfter = Math.max(1, Math.ceil((globalBucket[0] + windowMs - now) / 1000));
        return { allowed: false, retryAfter };
      }
      globalBucket.push(now);
    } else if (bucket.length >= maxAttempts) {
      const retryAfter = Math.max(1, Math.ceil((bucket[0] + windowMs - now) / 1000));
      return { allowed: false, retryAfter };
    }

    bucket.push(now);
    buckets.set(bucketKey, bucket);
    return { allowed: true };
  }

  return { check };
}

async function readJsonBody(request, maxBytes = MAX_BODY_BYTES) {
  const contentLengthHeader = request.headers['content-length'];
  if (contentLengthHeader !== undefined) {
    const contentLength = Number(contentLengthHeader);
    if (!Number.isFinite(contentLength) || contentLength < 0) {
      request.resume();
      throw new InvalidRequestBodyError();
    }
    if (contentLength > maxBytes) {
      request.resume();
      throw new BodyTooLargeError();
    }
  }

  return new Promise((resolve, reject) => {
    const chunks = [];
    let totalBytes = 0;
    let settled = false;

    const rejectOnce = (error) => {
      if (settled) return;
      settled = true;
      request.resume();
      reject(error);
    };

    request.on('data', (chunk) => {
      if (settled) return;
      totalBytes += chunk.length;
      if (totalBytes > maxBytes) {
        rejectOnce(new BodyTooLargeError());
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      if (settled) return;
      settled = true;
      resolve(Buffer.concat(chunks).toString('utf8'));
    });
    request.on('error', (error) => rejectOnce(error));
    request.on('aborted', () => rejectOnce(new InvalidRequestBodyError()));
  });
}

async function forwardNotification(payload, { env, fetchImpl, timeoutMs }) {
  const apiBase = typeof env.MANUS_API_URL === 'string' ? env.MANUS_API_URL.trim() : '';
  const apiKey = typeof env.MANUS_API_KEY === 'string' ? env.MANUS_API_KEY.trim() : '';
  if (!apiBase || !apiKey) return { accepted: false, configured: false };

  let endpoint;
  try {
    endpoint = new URL(`${apiBase.replace(/\/+$/u, '')}/webdevtoken.v1.WebDevService/SendNotification`);
    if (!['http:', 'https:'].includes(endpoint.protocol)) throw new Error('Unsupported protocol.');
  } catch {
    return { accepted: false, configured: true };
  }

  if (typeof fetchImpl !== 'function') return { accepted: false, configured: true };

  const controller = new AbortController();
  let timeoutHandle;
  try {
    const timeoutPromise = new Promise((_, reject) => {
      timeoutHandle = setTimeout(() => {
        controller.abort();
        reject(new Error('Notification timeout.'));
      }, timeoutMs);
      timeoutHandle.unref?.();
    });
    const response = await Promise.race([
      Promise.resolve().then(() => fetchImpl(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'connect-protocol-version': '1',
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      })),
      timeoutPromise,
    ]);

    const status = Number(response?.status);
    if (!Number.isFinite(status) || status < 200 || status >= 300) {
      return { accepted: false, configured: true };
    }

    let responseText = '';
    if (typeof response?.text === 'function') {
      try {
        responseText = await response.text();
      } catch {
        return { accepted: false, configured: true };
      }
    }

    if (responseText.trim()) {
      try {
        const responseBody = JSON.parse(responseText);
        if (responseBody && typeof responseBody === 'object' && responseBody.error != null) {
          return { accepted: false, configured: true };
        }
      } catch {
        return { accepted: false, configured: true };
      }
    }

    return { accepted: true, configured: true };
  } catch {
    return { accepted: false, configured: true };
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
    controller.abort();
  }
}

function notificationAccepted(result) {
  if (result === true || result === undefined) return true;
  if (!result || typeof result !== 'object') return false;
  return result.accepted === true || result.ok === true;
}

async function handleInquiry(request, response, config) {
  if (requestUsesCrossSiteFetch(request)) {
    sendJson(response, 403, { success: false, error: 'Cross-site requests are not accepted.' });
    return;
  }

  let rateDecision;
  try {
    rateDecision = config.rateLimiter.check(request);
  } catch {
    rateDecision = { allowed: true };
  }
  if (rateDecision === false || rateDecision?.allowed === false) {
    const retryAfter = Number(rateDecision?.retryAfter);
    if (Number.isFinite(retryAfter) && retryAfter > 0) response.setHeader('Retry-After', String(Math.ceil(retryAfter)));
    sendJson(response, 429, { success: false, error: 'Too many inquiries. Please try again later.' });
    return;
  }

  const contentType = typeof request.headers['content-type'] === 'string' ? request.headers['content-type'] : '';
  if (!/^application\/json(?:\s*;|\s*$)/iu.test(contentType)) {
    request.resume();
    sendJson(response, 415, { success: false, error: 'Content-Type must be application/json.' });
    return;
  }

  let bodyText;
  try {
    bodyText = await readJsonBody(request, config.maxBodyBytes);
  } catch (error) {
    if (error?.code === 'BODY_TOO_LARGE') {
      sendJson(response, 413, { success: false, error: 'Request body is too large.' });
    } else {
      sendJson(response, 400, { success: false, error: 'Invalid request body.' });
    }
    return;
  }

  let body;
  try {
    body = JSON.parse(bodyText);
  } catch {
    sendJson(response, 400, { success: false, error: 'Request body must be valid JSON.' });
    return;
  }

  const validation = validateInquiry(body);
  if (!validation.ok) {
    sendJson(response, 400, { success: false, error: 'Please check the inquiry fields.', fields: validation.errors });
    return;
  }

  const notification = buildNotification(validation.value);
  if (jsonByteLength(notification) > 20_000 || notification.title.length > 1200) {
    sendJson(response, 400, { success: false, error: 'Inquiry is too large.' });
    return;
  }

  let result;
  try {
    if (config.notificationSender) {
      result = await config.notificationSender(notification, { request });
    } else {
      result = await forwardNotification(notification, {
        env: config.env,
        fetchImpl: config.fetchImpl,
        timeoutMs: config.notificationTimeoutMs,
      });
    }
  } catch {
    result = { accepted: false, configured: true };
  }

  if (!notificationAccepted(result)) {
    if (result?.configured === false) {
      sendJson(response, 503, { success: false, error: 'Inquiry service is not configured.' });
    } else {
      sendJson(response, 502, { success: false, error: 'Inquiry could not be delivered.' });
    }
    return;
  }

  sendJson(response, 200, { success: true });
}

async function handleRequest(request, response, config) {
  let target;
  try {
    target = parseRequestTarget(request.url);
  } catch {
    sendJson(response, 400, { success: false, error: 'Invalid request target.' });
    return;
  }

  const method = String(request.method || 'GET').toUpperCase();
  const headOnly = method === 'HEAD';

  if (target.forbidden) {
    await serveNotFound(response, config.publicDir, { headOnly });
    return;
  }

  if (target.pathname === '/health') {
    if (method !== 'GET' && method !== 'HEAD') {
      sendMethodNotAllowed(response, 'GET, HEAD');
      return;
    }
    sendJson(response, 200, { success: true }, { headOnly });
    return;
  }

  if (target.pathname === '/api/inquiries') {
    if (method !== 'POST') {
      sendMethodNotAllowed(response, 'POST');
      return;
    }
    await handleInquiry(request, response, config);
    return;
  }

  if (method !== 'GET' && method !== 'HEAD') {
    sendMethodNotAllowed(response, 'GET, HEAD');
    return;
  }

  const file = await resolvePublicFile(config.publicDir, target.pathname);
  if (file) {
    await serveFile(response, file, { headOnly });
  } else {
    await serveNotFound(response, config.publicDir, { headOnly });
  }
}

export function createApp(options = {}) {
  const rateLimitOptions = options.rateLimit && typeof options.rateLimit === 'object' ? options.rateLimit : {};
  const env = options.env || process.env;
  const config = {
    publicDir: options.publicDir || DEFAULT_PUBLIC_DIR,
    env,
    fetchImpl: options.fetchImpl || options.fetch || globalThis.fetch,
    notificationSender: typeof options.notificationSender === 'function' ? options.notificationSender : null,
    notificationTimeoutMs: Number.isFinite(options.notificationTimeoutMs) ? options.notificationTimeoutMs : NOTIFICATION_TIMEOUT_MS,
    maxBodyBytes: Number.isFinite(options.maxBodyBytes) ? options.maxBodyBytes : MAX_BODY_BYTES,
    rateLimiter: typeof options.rateLimiter === 'function'
      ? { check: options.rateLimiter }
      : createRateLimiter({
        maxAttempts: rateLimitOptions.maxAttempts ?? options.rateLimitMax ?? RATE_LIMIT_MAX,
        windowMs: rateLimitOptions.windowMs ?? options.rateLimitWindowMs ?? RATE_LIMIT_WINDOW_MS,
        globalMaxAttempts: rateLimitOptions.globalMaxAttempts ?? options.globalRateLimitMax ?? GLOBAL_RATE_LIMIT_MAX,
        trustProxy: rateLimitOptions.trustProxy ?? options.trustProxy ?? String(env.TRUST_PROXY).toLowerCase() === 'true',
      }),
  };

  const server = createServer((request, response) => {
    handleRequest(request, response, config).catch(() => {
      if (!response.headersSent) sendJson(response, 500, { success: false, error: 'Internal server error.' });
      else if (!response.writableEnded) response.end();
    });
  });
  return server;
}

const isMainModule = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMainModule) {
  const server = createApp();
  const port = process.env.PORT || 3000;
  server.listen(port, '0.0.0.0');
}
