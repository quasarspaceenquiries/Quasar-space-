const menuToggle = document.querySelector('.menu-toggle');
const mobileNav = document.querySelector('#mobile-nav');
if (menuToggle && mobileNav) {
  const closeMenu = () => {
    const wasOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation');
    mobileNav.hidden = true;
    if (wasOpen && !window.matchMedia('(min-width: 801px)').matches) menuToggle.focus();
  };
  menuToggle.addEventListener('click', () => {
    const open = menuToggle.getAttribute('aria-expanded') !== 'true';
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    mobileNav.hidden = !open;
  });
  mobileNav.querySelectorAll('a, button').forEach(item => item.addEventListener('click', closeMenu));
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
  window.matchMedia('(min-width: 801px)').addEventListener('change', event => { if (event.matches) closeMenu(); });
}

const tabs = [...document.querySelectorAll('[data-program]')];
function activateProgram(tab, focus = false) {
  for (const item of tabs) {
    const active = item === tab;
    item.setAttribute('aria-selected', String(active));
    item.tabIndex = active ? 0 : -1;
    const panel = document.getElementById(item.getAttribute('aria-controls'));
    if (panel) panel.hidden = !active;
  }
  if (focus) tab.focus();
}
tabs.forEach((tab, index) => {
  tab.addEventListener('click', () => activateProgram(tab));
  tab.addEventListener('keydown', event => {
    let next;
    if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
    if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = tabs.length - 1;
    if (next !== undefined) { event.preventDefault(); activateProgram(tabs[next], true); }
  });
});

const dialog = document.querySelector('#contact-dialog');
const form = document.querySelector('#inquiry-form');
const formView = document.querySelector('#form-view');
const successView = document.querySelector('#success-view');
let lastTrigger = null;
let submissionInProgress = false;
if (dialog) {
  document.querySelectorAll('.contact-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
      lastTrigger = mobileNav && mobileNav.contains(trigger) ? menuToggle : trigger;
      if (formView) formView.hidden = false;
      if (successView) successView.hidden = true;
      const feedback = document.querySelector('#form-feedback');
      if (feedback) feedback.textContent = '';
      const topic = form?.querySelector('[name="topic"]');
      if (topic && trigger.dataset.topic) topic.value = trigger.dataset.topic;
      dialog.showModal();
    });
  });
  const closeDialog = () => dialog.close();
  dialog.querySelectorAll('.dialog-close').forEach(button => button.addEventListener('click', closeDialog));
  dialog.addEventListener('click', event => {
    if (event.target === dialog) {
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDialog();
    }
  });
  dialog.addEventListener('close', () => { if (lastTrigger) lastTrigger.focus(); });
}

if (form) {
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (submissionInProgress || !form.reportValidity()) return;
    const values = new FormData(form);
    const payload = {
      name: String(values.get('name') || '').trim(),
      email: String(values.get('email') || '').trim(),
      organization: String(values.get('organization') || '').trim(),
      topic: String(values.get('topic') || ''),
      message: String(values.get('message') || '').trim(),
      consent: values.get('consent') === 'on',
      website: String(values.get('website') || '')
    };
    const feedback = document.querySelector('#form-feedback');
    const submit = document.querySelector('#submit-inquiry');
    if (!feedback || !submit) return;
    submissionInProgress = true;
    submit.disabled = true;
    submit.innerHTML = 'Sending inquiry <span aria-hidden="true">↗</span>';
    feedback.textContent = '';
    try {
      const response = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(20000)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || result.message || 'Your inquiry could not be sent. Please try again shortly.');
      if (formView) formView.hidden = true;
      if (successView) {
        successView.hidden = false;
        form.reset();
        const focusTarget = successView.querySelector('.dialog-close') || successView;
        if (!focusTarget.hasAttribute('tabindex')) focusTarget.tabIndex = -1;
        focusTarget.focus();
      }
    } catch (error) {
      feedback.textContent = error.name === 'TimeoutError' || error.name === 'AbortError'
        ? 'The request timed out. Delivery could not be confirmed. Please wait a moment before trying again.'
        : error instanceof TypeError
          ? 'We couldn’t connect. Please check your connection and try again.'
          : error.message;
    } finally {
      submissionInProgress = false;
      submit.disabled = false;
      submit.innerHTML = 'Send inquiry <span aria-hidden="true">↗</span>';
    }
  });
}

const year = document.getElementById('year');
if (year) year.textContent = String(new Date().getFullYear());
