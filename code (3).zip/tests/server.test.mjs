import { strict as assert } from 'node:assert';
import { mkdtemp, mkdir, writeFile } from 'node:fs/promises';
import { request as httpRequest } from 'node:http';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { test } from 'node:test';
import { createApp } from '../server.mjs';

async function makePublicFixture({ notFound = false } = {}) {
  const root = await mkdtemp(path.join(tmpdir(), 'quasarspace-public-'));
  await mkdir(path.join(root, 'docs'));
  await writeFile(path.join(root, 'index.html'), '<!doctype html><title>Quasar Space</title>');
  await writeFile(path.join(root, 'docs', 'index.html'), 'docs index');
  await writeFile(path.join(root, 'app.js'), 'export const ready = true;');
  if (notFound) await writeFile(path.join(root, '404.html'), '<!doctype html><title>Missing</title>');
  return root;
}

function startTestServer(options) {
  const server = createApp(options);
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      resolve({ server, port: address.port });
    });
  });
}

function stopTestServer(server) {
  return new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
}

function request(port, { method = 'GET', path: requestPath = '/', headers = {}, body } = {}) {
  return new Promise((resolve, reject) => {
    const requestOptions = { hostname: '127.0.0.1', port, method, path: requestPath, headers };
    const requestInstance = httpRequest(requestOptions, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => resolve({
        statusCode: response.statusCode,
        headers: response.headers,
        body: Buffer.concat(chunks).toString('utf8'),
      }));
    });
    requestInstance.on('error', reject);
    if (body !== undefined) requestInstance.write(body);
    requestInstance.end();
  });
}

function inquiry(overrides = {}) {
  return {
    name: 'Ada Lovelace',
    email: 'ada@example.com',
    organization: 'Analytical Engines',
    topic: 'Partnership',
    message: 'We would like to explore a partnership around resilient orbital systems.',
    consent: true,
    website: '',
    ...overrides,
  };
}

test('serves health, MIME types, directory indexes, and a real 404 document', async (t) => {
  const publicDir = await makePublicFixture({ notFound: true });
  const { server, port } = await startTestServer({ publicDir });
  t.after(() => stopTestServer(server));

  const health = await request(port, { path: '/health?check=1' });
  assert.equal(health.statusCode, 200);
  assert.equal(health.headers['content-type'], 'application/json; charset=utf-8');
  assert.deepEqual(JSON.parse(health.body), { success: true });

  const root = await request(port, { path: '/' });
  assert.equal(root.statusCode, 200);
  assert.match(root.headers['content-type'], /^text\/html/);
  assert.match(root.body, /Quasar Space/);

  const directory = await request(port, { path: '/docs/' });
  assert.equal(directory.statusCode, 200);
  assert.equal(directory.body, 'docs index');

  const script = await request(port, { path: '/app.js' });
  assert.equal(script.statusCode, 200);
  assert.match(script.headers['content-type'], /^text\/javascript/);

  const missing = await request(port, { path: '/missing' });
  assert.equal(missing.statusCode, 404);
  assert.match(missing.body, /Missing/);
});

test('prevents decoded and normalized traversal from leaving public', async (t) => {
  const publicDir = await makePublicFixture();
  await writeFile(path.join(path.dirname(publicDir), 'outside-secret.txt'), 'not public');
  const { server, port } = await startTestServer({ publicDir });
  t.after(() => stopTestServer(server));

  for (const requestPath of ['/../outside-secret.txt', '/%2e%2e/outside-secret.txt', '/docs/../../outside-secret.txt']) {
    const response = await request(port, { path: requestPath });
    assert.equal(response.statusCode, 404, requestPath);
    assert.doesNotMatch(response.body, /not public/);
  }
});

test('validates inquiries and forwards only through an injected sender', async (t) => {
  const publicDir = await makePublicFixture();
  let received;
  const { server, port } = await startTestServer({
    publicDir,
    notificationSender: async (payload) => {
      received = payload;
      return { accepted: true };
    },
  });
  t.after(() => stopTestServer(server));

  const response = await request(port, {
    method: 'POST',
    path: '/api/inquiries',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(inquiry()),
  });
  assert.equal(response.statusCode, 200);
  assert.deepEqual(JSON.parse(response.body), { success: true });
  assert.equal(received.title, 'Quasar Space · Partnership inquiry');
  assert.match(received.content, /Name: Ada Lovelace/);
  assert.match(received.content, /Email: ada@example\.com/);
  assert.match(received.content, /Message:/);
  assert.doesNotMatch(received.content, /<[^>]+>/);
});

test('uses the configured Connect notification endpoint and rejects an upstream error object', async (t) => {
  const publicDir = await makePublicFixture();
  let call;
  const { server, port } = await startTestServer({
    publicDir,
    env: { MANUS_API_URL: 'https://api.example.test/base/', MANUS_API_KEY: 'test-key' },
    fetchImpl: async (url, options) => {
      call = { url: String(url), options };
      return { status: 200, text: async () => JSON.stringify({ error: { message: 'not accepted' } }) };
    },
  });
  t.after(() => stopTestServer(server));

  const response = await request(port, {
    method: 'POST',
    path: '/api/inquiries',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(inquiry()),
  });
  assert.equal(response.statusCode, 502);
  assert.equal(call.url, 'https://api.example.test/base/webdevtoken.v1.WebDevService/SendNotification');
  assert.equal(call.options.method, 'POST');
  assert.equal(call.options.headers.Authorization, 'Bearer test-key');
  assert.equal(call.options.headers['Content-Type'], 'application/json');
  assert.equal(call.options.headers['connect-protocol-version'], '1');
  assert.equal(JSON.parse(call.options.body).title, 'Quasar Space · Partnership inquiry');
});

test('rejects invalid inquiry fields and oversized JSON bodies', async (t) => {
  const publicDir = await makePublicFixture();
  const { server, port } = await startTestServer({
    publicDir,
    notificationSender: async () => ({ accepted: true }),
    rateLimit: { maxAttempts: 50, globalMaxAttempts: 50 },
  });
  t.after(() => stopTestServer(server));

  const invalid = await request(port, {
    method: 'POST',
    path: '/api/inquiries',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(inquiry({ email: 'not-an-email', consent: 'yes', message: 'too short' })),
  });
  assert.equal(invalid.statusCode, 400);
  assert.equal(JSON.parse(invalid.body).success, false);

  const oversized = await request(port, {
    method: 'POST',
    path: '/api/inquiries',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(inquiry({ message: 'x'.repeat(13_000) })),
  });
  assert.equal(oversized.statusCode, 413);
});

test('maps missing configuration and upstream failures to transparent non-success responses', async (t) => {
  const publicDir = await makePublicFixture();
  const missingConfig = createApp({ publicDir, env: {}, fetchImpl: async () => { throw new Error('must not call'); } });
  await new Promise((resolve) => missingConfig.listen(0, '127.0.0.1', resolve));
  const missingPort = missingConfig.address().port;
  t.after(() => stopTestServer(missingConfig));

  const missingResponse = await request(missingPort, {
    method: 'POST',
    path: '/api/inquiries',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(inquiry()),
  });
  assert.equal(missingResponse.statusCode, 503);
  assert.equal(JSON.parse(missingResponse.body).success, false);

  const failed = await startTestServer({
    publicDir,
    env: { MANUS_API_URL: 'https://owner.invalid', MANUS_API_KEY: 'test-only' },
    notificationSender: async () => ({ accepted: false }),
  });
  t.after(() => stopTestServer(failed.server));
  const failedResponse = await request(failed.port, {
    method: 'POST',
    path: '/api/inquiries',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(inquiry()),
  });
  assert.equal(failedResponse.statusCode, 502);
  assert.equal(JSON.parse(failedResponse.body).success, false);
});
