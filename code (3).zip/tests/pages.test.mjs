import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const publicDir = fileURLToPath(new URL('../public/', import.meta.url));
const readPublic = route => readFileSync(path.join(publicDir, route === '/' ? 'index.html' : route.replace(/^\//, '')), 'utf8');
const manifest = JSON.parse(readPublic('/manus-routes.json'));
const mainPages = ['/mission.html', '/capabilities.html', '/programs.html', '/journal.html', '/careers.html', '/contact.html'];

test('manifest represents all twelve public page documents with useful titles and content', () => {
  assert.equal(manifest.routes.length, 12);
  const titles = new Set();
  for (const route of manifest.routes) {
    const source = readPublic(route.path);
    assert.match(source, /<h1(?:\s|>)/, `${route.path} should include a visible primary heading`);
    assert.match(source, /<main(?:\s|>)/, `${route.path} should include its semantic main content`);
    assert.match(source, /name="description"\s+content="[^"]+"/, `${route.path} should include a useful description`);
    const title = source.match(/<title>(.*?)<\/title>/s)?.[1];
    assert.ok(title && !titles.has(title), `${route.path} must have a unique document title`);
    titles.add(title);
  }
});

test('all page documents share real mobile navigation and the six new destinations', () => {
  for (const route of manifest.routes) {
    const source = readPublic(route.path);
    assert.match(source, /class="menu-toggle"/, `${route.path} requires the mobile menu control`);
    assert.match(source, /id="mobile-nav"/, `${route.path} requires the mobile nav target`);
    assert.match(source, /<script src="\/app\.js" defer>/, `${route.path} must load the shared behavior`);
    for (const destination of mainPages) {
      assert.ok(source.includes(`href="${destination}"`), `${route.path} must link to ${destination}`);
    }
  }
});

test('all local page links and fragment references resolve without a SPA fallback', () => {
  for (const route of manifest.routes) {
    const source = readPublic(route.path);
    for (const match of source.matchAll(/href="([^"]+)"/g)) {
      const value = match[1];
      if (!value.startsWith('/') && !value.startsWith('#')) continue;
      const address = new URL(value, 'http://quasarspace.test' + (route.path === '/' ? '/' : route.path));
      if (address.pathname.startsWith('/manus-storage/')) continue;
      const file = path.join(publicDir, address.pathname === '/' ? 'index.html' : address.pathname.replace(/^\//, ''));
      assert.ok(existsSync(file), `${route.path} contains a missing local destination: ${value}`);
      if (address.hash) {
        const destination = readFileSync(file, 'utf8');
        const id = decodeURIComponent(address.hash.substring(1));
        assert.ok(destination.includes(`id="${id}"`), `${route.path} contains a missing fragment destination: ${value}`);
      }
    }
  }
});

test('dedicated contact document uses the existing real inquiry field contract without a modal', () => {
  const source = readPublic('/contact.html');
  assert.match(source, /id="inquiry-form"/);
  assert.match(source, /id="form-view"/);
  assert.match(source, /id="success-view"[^>]*hidden|hidden[^>]*id="success-view"/);
  assert.match(source, /id="form-feedback"/);
  assert.match(source, /id="submit-inquiry"/);
  assert.doesNotMatch(source, /<dialog(?:\s|>)/);
  for (const field of ['name', 'email', 'organization', 'topic', 'message', 'consent', 'website']) {
    assert.ok(source.includes(`name="${field}"`), `Missing inquiry field ${field}`);
  }
  assert.ok(source.includes('href="/privacy.html"'));
});
