# Quasar Space website server

This repository contains the native Node.js server wrapper for the Quasar Space space-exploration company website. The **Quasar Space** brand name is an assumed working identity for this project. The mission, program, milestone, and project concepts presented by the site are illustrative positioning content, not a flight record or claim of completed missions.

## Run locally

Node.js 22 or newer is required. The server has no npm dependencies and serves the `public/` directory directly.

```sh
npm test
npm run check
npm start
```

The listener binds to `0.0.0.0` and uses `PORT` when supplied, otherwise port `3000`. `GET /health` returns a small JSON success response. Static directories use an `index.html` file when present, and missing paths use `public/404.html` when present or a plain-text 404 response.

## Partnership inquiry endpoint

`POST /api/inquiries` accepts a JSON body containing:

- `name`: required, 2–100 characters
- `email`: required, a sane email address no longer than 254 characters
- `organization`: optional, no longer than 120 characters
- `topic`: one of `Partnership`, `Mission services`, `Careers`, `Press`, or `Other`
- `message`: required, 20–3000 characters
- `consent`: required and exactly `true`
- `website`: honeypot field; it must be empty when supplied

JSON request bodies are limited to 12 KiB. The endpoint rejects browser requests marked with `Sec-Fetch-Site: cross-site`, applies a best-effort in-memory rate limit, and never writes inquiry payloads or personally identifying form fields to logs. It does not create a contact database.

For delivery, configure the server environment with `MANUS_API_URL` and `MANUS_API_KEY`. A valid inquiry is forwarded to the owner-only Manus notification service at:

```text
POST $MANUS_API_URL/webdevtoken.v1.WebDevService/SendNotification
```

The request uses the required bearer authorization, JSON content type, and `connect-protocol-version: 1` header. A 2xx upstream response with no error object is treated as **accepted for owner notification**. That does not mean the owner has read it, and this endpoint is not a customer email channel. Missing configuration returns 503; an upstream error or timeout returns 502 without claiming success.

## Deployment

The included `Dockerfile` uses `node:22-alpine`, runs as the non-root `node` user, exposes port 3000, and starts `server.mjs`. Public-origin SEO metadata is intentionally omitted until the production origin and publication details are confirmed.
